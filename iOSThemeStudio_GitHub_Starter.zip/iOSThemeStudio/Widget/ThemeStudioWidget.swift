import WidgetKit
import SwiftUI

struct ThemeEntry: TimelineEntry {
    let date: Date
    let theme: ThemeStyle
}

struct ThemeProvider: TimelineProvider {
    func placeholder(in context: Context) -> ThemeEntry {
        ThemeEntry(date: .now, theme: .ocean)
    }

    func getSnapshot(in context: Context, completion: @escaping (ThemeEntry) -> Void) {
        completion(ThemeEntry(date: .now, theme: ThemeStore.selected))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<ThemeEntry>) -> Void) {
        let entry = ThemeEntry(date: .now, theme: ThemeStore.selected)
        let next = Calendar.current.date(byAdding: .minute, value: 30, to: .now) ?? .now.addingTimeInterval(1800)
        completion(Timeline(entries: [entry], policy: .after(next)))
    }
}

struct ThemeStudioWidgetView: View {
    let entry: ThemeEntry
    @Environment(\.widgetFamily) private var family

    var body: some View {
        ZStack {
            LinearGradient(colors: entry.theme.colors, startPoint: .topLeading, endPoint: .bottomTrailing)
            if family == .systemSmall {
                VStack(alignment: .leading, spacing: 5) {
                    Image(systemName: entry.theme.symbol).font(.title2)
                    Text(Date.now.formatted(date: .abbreviated, time: .omitted)).font(.caption)
                    Text(Date.now.formatted(date: .omitted, time: .shortened))
                        .font(.system(size: 27, weight: .semibold, design: .rounded))
                    Text(entry.theme.title).font(.caption2)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                .padding()
            } else {
                HStack(spacing: 14) {
                    VStack(alignment: .leading, spacing: 7) {
                        Text(entry.theme.title).font(.headline)
                        Text(Date.now.formatted(date: .complete, time: .omitted)).font(.caption)
                        Text(Date.now.formatted(date: .omitted, time: .shortened))
                            .font(.system(size: 34, weight: .light, design: .rounded))
                    }
                    Spacer()
                    Image(systemName: entry.theme.symbol)
                        .font(.system(size: 42))
                }
                .padding()
            }
        }
        .foregroundStyle(entry.theme.foreground)
        .containerBackground(.clear, for: .widget)
    }
}

@main
struct ThemeStudioWidget: Widget {
    let kind = "ThemeStudioWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: ThemeProvider()) { entry in
            ThemeStudioWidgetView(entry: entry)
        }
        .configurationDisplayName("Theme Studio")
        .description("Widget đồng hồ và màu sắc theo chủ đề.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}
