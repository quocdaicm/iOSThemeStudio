# iOS Theme Studio 2026

SwiftUI + WidgetKit starter project. The repository is designed to build on GitHub Actions using a macOS runner.

## Included
- SwiftUI home screen with theme gallery, preview, favorites and local persistence
- Five bundled visual themes (Blue, Pastel, Cyber, Nature, Minimal)
- WidgetKit home-screen widget with small/medium/large families
- Widget configuration via the app's selected theme (shared App Group)
- Wallpaper-style gradient gallery and save-to-Photos flow (requires Photos permission)
- Custom icon/theme guidance (iOS does not allow replacing other apps' icons silently)
- GitHub Actions workflow for unsigned build and signed IPA export

## Important iOS limits
An app cannot replace the iOS SpringBoard, status bar, app layout, or other apps' icons directly. It can provide widgets, wallpapers, theme previews, and custom Home Screen icons via Shortcuts/web clips or configuration profiles where appropriate. Widget refresh is scheduled by iOS and is not guaranteed every second.

## Build locally
1. Install Xcode 16+ and XcodeGen (`brew install xcodegen`).
2. In this directory run:
   ```bash
   xcodegen generate
   open iOSThemeStudio.xcodeproj
   ```
3. Select the `iOSThemeStudio` scheme and a real iPhone or simulator.
4. For a device build, set your own Team and Bundle Identifier in `project.yml`.

## Build with GitHub Actions
Push this repository to GitHub. The workflow `.github/workflows/ios-build.yml` supports:
- **Unsigned build**: builds an archive without signing, useful for CI validation but not installable as-is.
- **Signed IPA**: requires the repository secrets below.

### GitHub repository secrets for signed IPA
- `IOS_CERTIFICATE_P12_BASE64`: base64 of an Apple Development or Distribution `.p12` certificate
- `IOS_CERTIFICATE_PASSWORD`: password for that `.p12`
- `IOS_PROVISIONING_PROFILE_BASE64`: base64 of the app target's provisioning profile
- `IOS_WIDGET_PROFILE_BASE64`: base64 of the widget extension's provisioning profile
- `IOS_TEAM_ID`: Apple Developer Team ID

Use the sample bundle IDs in `project.yml` only for local preview. Before signed export, replace `com.example.iosthemestudio` and `com.example.iosthemestudio.widget` with App IDs registered to your Apple Developer team, and replace the App Group `group.com.example.iosthemestudio` in both entitlements and `ThemeStore.groupID` with your registered App Group. Create separate matching profiles for the app and widget extension. For Ad Hoc, both profiles must include the intended device UDIDs. For App Store/TestFlight, use App Store profiles and change the export method in the workflow to `app-store`.

### Run
GitHub → Actions → `iOS Build` → Run workflow → choose `unsigned` or `signed`.

The IPA/xcarchive is uploaded as a workflow artifact. GitHub Actions does not magically bypass Apple's signing requirements.

## Project identity
Before public distribution, change the sample bundle identifiers and app group in `project.yml` to identifiers owned by your Apple Developer team.
