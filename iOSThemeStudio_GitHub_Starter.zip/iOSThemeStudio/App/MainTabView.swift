import SwiftUI
import WidgetKit

struct MainTabView: View {
    @AppStorage(ThemeStore.selectedKey, store: UserDefaults(suiteName: ThemeStore.groupID))
    private var selectedRaw = ThemeStyle.ocean.rawValue

    private var theme: ThemeStyle { ThemeStyle(rawValue: selectedRaw) ?? .ocean }

    var body: some View {
        TabView {
            HomeView(theme: theme)
                .tabItem { Label("Khám phá", systemImage: "sparkles") }
            WidgetStudioView(theme: theme)
                .tabItem { Label("Widget", systemImage: "square.grid.2x2") }
            WallpaperView(theme: theme)
                .tabItem { Label("Hình nền", systemImage: "photo") }
            SettingsView()
                .tabItem { Label("Cài đặt", systemImage: "gearshape") }
        }
        .tint(Color(hex: 0x2389D7))
        .onChange(of: selectedRaw) { _, _ in WidgetCenter.shared.reloadAllTimelines() }
    }
}
