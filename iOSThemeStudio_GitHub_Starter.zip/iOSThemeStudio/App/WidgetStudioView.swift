import SwiftUI
import WidgetKit

struct WidgetStudioView: View {
    let theme: ThemeStyle

    var body: some View {
        NavigationStack {
            List {
                Section("Widget có sẵn") {
                    widgetRow("Thời tiết", "cloud.sun.fill", "Bản demo; cần API thời tiết để có dữ liệu thật.")
                    widgetRow("Đồng hồ", "clock.fill", "Hiển thị giờ hệ thống.")
                    widgetRow("Lịch", "calendar", "Hiển thị ngày hiện tại.")
                    widgetRow("Chủ đề", "paintpalette.fill", "Đồng bộ màu theo theme đang chọn.")
                }
                Section("Cách thêm vào màn hình chính") {
                    Text("1. Nhấn giữ vùng trống trên Home Screen.")
                    Text("2. Chạm dấu + ở góc màn hình.")
                    Text("3. Tìm “Theme Widgets”.")
                    Text("4. Chọn widget và kích thước, sau đó chạm Thêm tiện ích.")
                }
                Section {
                    Button {
                        WidgetCenter.shared.reloadAllTimelines()
                    } label: {
                        Label("Làm mới widget", systemImage: "arrow.clockwise")
                    }
                }
            }
            .navigationTitle("Widget Studio")
        }
    }

    private func widgetRow(_ title: String, _ icon: String, _ detail: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.title2).foregroundStyle(.blue).frame(width: 34)
            VStack(alignment: .leading) {
                Text(title).font(.headline)
                Text(detail).font(.caption).foregroundStyle(.secondary)
            }
        }
        .padding(.vertical, 4)
    }
}
