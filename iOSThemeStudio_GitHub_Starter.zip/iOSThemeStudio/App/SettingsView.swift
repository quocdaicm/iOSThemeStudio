import SwiftUI

struct SettingsView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("Ứng dụng") {
                    LabeledContent("Tên", value: "iOS Theme Studio")
                    LabeledContent("Phiên bản", value: "1.0.0 starter")
                    LabeledContent("Nền tảng", value: "iOS 17 trở lên")
                }
                Section("Giới hạn iOS") {
                    Text("Ứng dụng không thể thay đổi trực tiếp thanh trạng thái, SpringBoard hoặc bố cục hệ thống.")
                    Text("Icon tùy chỉnh cho ứng dụng khác cần thiết lập qua Phím tắt; không thể thay icon hàng loạt một cách âm thầm.")
                    Text("Widget được iOS quản lý lịch cập nhật nên không bảo đảm cập nhật tức thời.")
                }
                Section("Hỗ trợ") {
                    Link("Tài liệu Apple WidgetKit", destination: URL(string: "https://developer.apple.com/documentation/widgetkit")!)
                    Link("Tài liệu SwiftUI", destination: URL(string: "https://developer.apple.com/documentation/swiftui")!)
                }
            }
            .navigationTitle("Cài đặt")
        }
    }
}
