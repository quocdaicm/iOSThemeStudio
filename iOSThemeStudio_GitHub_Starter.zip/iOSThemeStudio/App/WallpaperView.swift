import SwiftUI
import Photos
import UIKit

struct WallpaperView: View {
    let theme: ThemeStyle
    @State private var status = ""

    private let palettes: [(String, [Color])] = [
        ("Blue Flow", [Color(hex: 0x70D6FF), Color(hex: 0x2784C7), Color(hex: 0xC7F1FF)]),
        ("Pink Dream", [Color(hex: 0xFFD1E8), Color(hex: 0xC5B7FF), Color(hex: 0xFFF4F8)]),
        ("Deep Space", [Color(hex: 0x050A24), Color(hex: 0x123B76), Color(hex: 0x16C6D9)]),
        ("Green Lake", [Color(hex: 0xC4E8B5), Color(hex: 0x4C9C88), Color(hex: 0xD8F3E4)])
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Hình nền gradient tạo ngay trong ứng dụng")
                        .font(.subheadline).foregroundStyle(.secondary)
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                        ForEach(palettes, id: \.0) { item in
                            VStack(alignment: .leading, spacing: 8) {
                                RoundedRectangle(cornerRadius: 22)
                                    .fill(LinearGradient(colors: item.1, startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .aspectRatio(0.68, contentMode: .fit)
                                Text(item.0).font(.headline)
                                Button("Lưu hình nền") { saveWallpaper(name: item.0, colors: item.1) }
                                    .buttonStyle(.borderedProminent)
                            }
                        }
                    }
                    if !status.isEmpty { Text(status).font(.footnote).foregroundStyle(.secondary) }
                }
                .padding()
            }
            .navigationTitle("Wallpaper")
        }
    }

    @MainActor
    private func saveWallpaper(name: String, colors: [Color]) {
        let size = CGSize(width: 1170, height: 2532)
        let renderer = ImageRenderer(content:
            LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing)
                .frame(width: size.width, height: size.height)
        )
        renderer.scale = 1
        guard let image = renderer.uiImage else {
            status = "Không tạo được hình ảnh."
            return
        }
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { permission in
            guard permission == .authorized || permission == .limited else {
                Task { @MainActor in status = "Bạn chưa cấp quyền thêm ảnh vào thư viện." }
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAsset(from: image)
            }) { success, error in
                Task { @MainActor in
                    status = success ? "Đã lưu \(name) vào Ảnh." : (error?.localizedDescription ?? "Lưu ảnh thất bại.")
                }
            }
        }
    }
}
