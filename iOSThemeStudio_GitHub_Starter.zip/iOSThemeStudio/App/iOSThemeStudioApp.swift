import SwiftUI

@main
struct iOSThemeStudioApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
