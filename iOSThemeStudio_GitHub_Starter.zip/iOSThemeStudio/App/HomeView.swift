import SwiftUI
import WidgetKit

struct HomeView: View {
    let theme: ThemeStyle
    @State private var showAll = false

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: theme.colors, startPoint: .topLeading, endPoint: .bottomTrailing)
                    .ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        header
                        previewCard
                        HStack {
                            Text("Chủ đề nổi bật").font(.title2.bold())
                            Spacer()
                            Button("Xem tất cả") { showAll = true }
                                .font(.subheadline.weight(.semibold))
                        }
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 14) {
                            ForEach(ThemeStyle.allCases) { item in
                                ThemeCard(theme: item, selected: item == theme) {
                                    ThemeStore.select(item)
                                    WidgetCenter.shared.reloadAllTimelines()
                                }
                            }
                        }
                        tipsCard
                    }
                    .padding()
                }
            }
            .navigationTitle("iOS Theme Studio")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showAll) { ThemeGalleryView(current: theme) }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Cá nhân hóa iPhone")
                .font(.largeTitle.bold())
            Text("Chọn phong cách phù hợp với bạn")
                .font(.subheadline)
                .opacity(0.8)
        }
        .foregroundStyle(theme.foreground)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var previewCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Label(theme.title, systemImage: theme.symbol)
                    .font(.headline)
                Spacer()
                Text("ĐANG XEM TRƯỚC")
                    .font(.caption2.bold())
                    .padding(7)
                    .background(.ultraThinMaterial, in: Capsule())
            }
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Thời tiết").font(.caption)
                    Text("31°").font(.system(size: 42, weight: .light))
                    Label("Có mây", systemImage: "cloud.fill").font(.caption)
                    Text("33° / 26°").font(.caption)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
                VStack(alignment: .leading, spacing: 8) {
                    Text(Date.now.formatted(.dateTime.weekday(.wide)))
                        .font(.caption.bold())
                    Text(Date.now.formatted(.dateTime.day()))
                        .font(.system(size: 42, weight: .light))
                    Text("0 sự kiện hôm nay").font(.caption)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
            }
            Text("Bản xem trước minh họa — dữ liệu thời tiết chưa kết nối dịch vụ.")
                .font(.caption2)
                .opacity(0.75)
        }
        .foregroundStyle(theme.foreground)
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28))
    }

    private var tipsCard: some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Mẹo sử dụng", systemImage: "lightbulb.fill").font(.headline)
            Text("Thêm widget: nhấn giữ màn hình chính iPhone → dấu + → tìm “Theme Widgets” → chọn kích thước.")
                .font(.subheadline)
        }
        .foregroundStyle(theme.foreground)
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
    }
}

struct ThemeCard: View {
    let theme: ThemeStyle
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 9) {
                RoundedRectangle(cornerRadius: 16)
                    .fill(LinearGradient(colors: theme.colors, startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(height: 92)
                    .overlay {
                        Image(systemName: theme.symbol)
                            .font(.system(size: 32, weight: .medium))
                            .foregroundStyle(theme.foreground)
                    }
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(theme.title).font(.headline)
                        Text(theme.subtitle).font(.caption)
                            .lineLimit(1)
                    }
                    Spacer(minLength: 0)
                    if selected { Image(systemName: "checkmark.circle.fill").foregroundStyle(.green) }
                }
                .foregroundStyle(.primary)
            }
            .padding(10)
            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(selected ? .blue : .clear, lineWidth: 2))
        }
        .buttonStyle(.plain)
    }
}

struct ThemeGalleryView: View {
    let current: ThemeStyle
    var body: some View {
        NavigationStack {
            List(ThemeStyle.allCases) { theme in
                HStack {
                    Circle().fill(LinearGradient(colors: theme.colors, startPoint: .top, endPoint: .bottom))
                        .frame(width: 42, height: 42)
                    VStack(alignment: .leading) {
                        Text(theme.title).font(.headline)
                        Text(theme.subtitle).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    if theme == current { Image(systemName: "checkmark").foregroundStyle(.blue) }
                }
            }
            .navigationTitle("Thư viện giao diện")
        }
    }
}
