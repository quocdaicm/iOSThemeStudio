import SwiftUI

enum ThemeStyle: String, CaseIterable, Identifiable, Codable {
    case ocean, pastel, cyber, nature, minimal

    var id: String { rawValue }

    var title: String {
        switch self {
        case .ocean: "Blue Glass"
        case .pastel: "Cute Pastel"
        case .cyber: "Cyber Space"
        case .nature: "Nature"
        case .minimal: "Minimal"
        }
    }

    var subtitle: String {
        switch self {
        case .ocean: "Xanh dương dịu nhẹ"
        case .pastel: "Hồng pastel trẻ trung"
        case .cyber: "Công nghệ tương lai"
        case .nature: "Trong lành và thư giãn"
        case .minimal: "Tối giản thanh lịch"
        }
    }

    var colors: [Color] {
        switch self {
        case .ocean: [Color(hex: 0x8ED8F8), Color(hex: 0x267DBB), Color(hex: 0xD9F4FF)]
        case .pastel: [Color(hex: 0xFFD6E7), Color(hex: 0xB9DFFF), Color(hex: 0xFFF4F8)]
        case .cyber: [Color(hex: 0x07162F), Color(hex: 0x075B9A), Color(hex: 0x19D5E8)]
        case .nature: [Color(hex: 0xA7D9B3), Color(hex: 0x3E9279), Color(hex: 0xE5F5D9)]
        case .minimal: [Color(hex: 0xF5F7FA), Color(hex: 0xB9C5D3), Color(hex: 0xFFFFFF)]
        }
    }

    var foreground: Color {
        self == .cyber ? .white : Color(hex: 0x16324A)
    }

    var symbol: String {
        switch self {
        case .ocean: "water.waves"
        case .pastel: "heart.fill"
        case .cyber: "sparkles"
        case .nature: "leaf.fill"
        case .minimal: "circle.lefthalf.filled"
        }
    }
}

extension Color {
    init(hex: UInt, opacity: Double = 1) {
        self.init(.sRGB,
                  red: Double((hex >> 16) & 0xFF) / 255,
                  green: Double((hex >> 8) & 0xFF) / 255,
                  blue: Double(hex & 0xFF) / 255,
                  opacity: opacity)
    }
}

enum ThemeStore {
    static let groupID = "group.com.example.iosthemestudio"
    static let selectedKey = "selectedTheme"

    static var selected: ThemeStyle {
        let raw = UserDefaults(suiteName: groupID)?.string(forKey: selectedKey) ?? ThemeStyle.ocean.rawValue
        return ThemeStyle(rawValue: raw) ?? .ocean
    }

    static func select(_ theme: ThemeStyle) {
        UserDefaults(suiteName: groupID)?.set(theme.rawValue, forKey: selectedKey)
    }
}
